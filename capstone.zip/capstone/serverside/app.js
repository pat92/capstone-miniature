const express = require('express');
const app = express();
const mongoose = require('mongoose');
const project = require('./models/project');
//connect and display the status 
mongoose.connect('mongodb://localhost:27017/capstone', { useNewUrlParser: true,  useUnifiedTopology: true })
    .then(() => { console.log("connected"); })
    .catch(() => { console.log("error connecting"); });

app.use((req, res, next) => {
    console.log('This line is always called');
    res.setHeader('Access-Control-Allow-Origin', '*'); //can connect from any host
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS, DELETE'); //allowable methods
    res.setHeader('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept');
    next();
});
//parse application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: false }))

//parse application/json
app.use(express.json())

//in the app.get() method below we add a path for the students API 
//by adding /students, we tell the server that this method will be called every time http://localhost:8000/students is requested. 
app.get('/projectProposal', (req, res, next) => {
    // //we will add an array named students to pretend that we received this data from the database
project.find() 
//if data is returned, send data as a response 
.then(data => res.status(200).json(data))
//if error, send internal server error
.catch(err => {
console.log('Error: ${err}');
res.status(500).json(err);
});

});

//serve incoming post requests to /project
app.post('/projectProposal', (req, res, next) => {
    const projectReq = new project({
        contactName: req.body.contactName,
        contactJobTitle: req.body.contactJobTitle,
        contactEmail: req.body.contactEmail,
        contactPhone: req.body.contactPhone,
        organizationName: req.body.organizationName,
        organizationWebsite: req.body.organizationWebsite,
    })
    projectReq.save()
    //incase of success
    .then(() => {console.log('Success');})
    //if error
    .catch(err => {console.log('Error' + err);});
});

//:id is a dynamic parameter that will be extracted from the URL
app.delete("/projectProposal/:id", (req, res, next) => {
    project.deleteOne({ _id: req.params.id }).then(result => {
        console.log(result);
        res.status(200).json("Deleted!");
    });
});

//serve incoming put requests to /projectProposal
app.put('/projectProposal/:id', (req, res, next) => { 
    console.log("id: " + req.params.id) 
    // check that the parameter id is valid 
    if (mongoose.Types.ObjectId.isValid(req.params.id)) { 
        //find a document and set new first and last names 
        project.findOneAndUpdate( 
            {_id: req.params.id}, 
            {$set:{ 
                contactName: req.body.contactName,
                contactJobTitle: req.body.contactJobTitle,
                contactEmail: req.body.contactEmail,
                contactPhone: req.body.contactPhone,
                organizationName: req.body.organizationName,
                organizationWebsite: req.body.organizationWebsite,
            }}, 
            {new:true} 
        ) 
        .then((project) => { 
            if (project) { //what was updated 
                console.log(project); 
            } else { 
                console.log("no data exist for this id"); 
            } 
        }) 
        .catch((err) => { 
            console.log(err); 
        }); 
    } else { 
        console.log("please provide correct id"); 
    } 
});

//find a project based on the id
app.get('/projectProposal/:id', (req, res, next) => {
    //call mongoose method findOne (MongoDB db.Students.findOne())
    project.findOne({_id: req.params.id}) 
        //if data is returned, send data as a response 
        .then(data => {
            res.status(200).json(data)
            console.log(data);
        })
        //if error, send internal server error
        .catch(err => {
        console.log('Error: ${err}');
        res.status(500).json(err);
    });
});

//serve incoming put requests to /students 
app.put('/students/:id', (req, res, next) => { 
    console.log("id: " + req.params.id) 
    // check that the parameter id is valid 
    if (mongoose.Types.ObjectId.isValid(req.params.id)) { 
        //find a document and set new first and last names 
        Student.findOneAndUpdate( 
            {_id: req.params.id}, 
            {$set:{ 
                firstName : req.body.firstName, 
                lastName : req.body.lastName 
            }}, 
            {new:true} 
        ) 
        .then((student) => { 
            if (student) { //what was updated 
                console.log(student); 
            } else { 
                console.log("no data exist for this id"); 
            } 
        }) 
        .catch((err) => { 
            console.log(err); 
        }); 
    } else { 
        console.log("please provide correct id"); 
    } 
});

//find a student based on the id
app.get('/students/:id', (req, res, next) => {
    //call mongoose method findOne (MongoDB db.Students.findOne())
    project.findOne({_id: req.params.id}) 
        //if data is returned, send data as a response 
        .then(data => {
            res.status(200).json(data)
            console.log(data);
        })
        //if error, send internal server error
        .catch(err => {
        console.log('Error: ${err}');
        res.status(500).json(err);
    });
});

//to use this middleware in other parts of the application
module.exports=app;