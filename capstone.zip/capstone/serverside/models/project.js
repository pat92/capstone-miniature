const mongoose = require('mongoose');

//define a schema/ blueprint NOTE: id is not a part of the schema 
const projectSchema = new mongoose.Schema({
    contactName:  { type: String, required: true},
    contactJobTitle:  { type: String, required: true},
    contactEmail:  { type: String, required: true},
    contactPhone:  { type: Number, required: true},
    organizationName:  { type: String, required: true},
    organizationWebsite:  { type: String, required: true},
    // organizationAddress:  { 
    //     street: { type: String },
    //     zip: { type: Number },
    //     city: { type: String },
    //     state: { type: String }
    // },
    // projectTitle: {type: String },


});

//use the blueprint to create the model 
//Parameters: (model_name, schema_to_use, collection_name)
//module.exports is used to allow external access to the model  
module.exports = mongoose.model('project', projectSchema,'projects');
//note capital S in the collection name