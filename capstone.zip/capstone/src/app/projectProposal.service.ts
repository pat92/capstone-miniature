import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
//we know that response will be in JSON format
const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class ProjectProposalService {

    constructor(private http:HttpClient, private router: Router) {
       // this.url = 'listProject';
    }

    // Uses http.get() to load data 
    getProjectProposals() {
        return this.http.get('http://localhost:9000/projectProposal');
    }

    //Uses http.post() to post data 
    addProjectProposal(contactName: string, contactJobTitle: string, contactEmail: string, contactPhone: string, organizationName: String, organizationWebsite: String) {
    this.http.post('http://localhost:9000/projectProposal',{ contactName, contactJobTitle, contactEmail, contactPhone,organizationName, organizationWebsite})
        .subscribe((responseData) => {
            console.log(responseData);
        });
        this.reloadCurrentRoute();
        //window.location.href = window.location.href;
        //location.reload(); 
    }
    deleteProject(projectId: string) {
        this.http.delete("http://localhost:9000/projectProposal/" + projectId)
            .subscribe(() => {
                console.log('Deleted: ' + projectId);
            });
            this.reloadCurrentRoute();
            //window.location.href = window.location.href;
            //location.reload();
    }
    updateProjectProposal(projectId: string,contactName: string, contactJobTitle: string, contactEmail: string, contactPhone: string, organizationName: String, organizationWebsite: String) {
        //first and last names will be send as HTTP body parameters 
        this.http.put("http://localhost:9000/projectProposal/" + 
        projectId,{ contactName, contactJobTitle, contactEmail, contactPhone,organizationName, organizationWebsite})
        .subscribe(() => {
            console.log('Updated: ' + projectId);
            //this.ngOnInit();
        });
        //window.location.href = window.location.href;
        //location.reload();
        this.reloadCurrentRoute();
    }
    

    // Uses http.get() to load data 
    getProjectProposal(projectId: string) {
        return this.http.get('http://localhost:9000/projectProposal/'+projectId);
    }

    
    reloadCurrentRoute() {
        this.router.navigate([this.router.url])
    }
    
            
}