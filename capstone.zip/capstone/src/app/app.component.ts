import { Component } from '@angular/core';
// import { StudentService } from './student.service';
 //import { ProjectProposalService } from './projectProposal.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  
//   title ='Capstone Project Proposal App';
//   //declare variable to hold response and make it public to be accessible from components.html
//   public students: any;
//   //initialize the call using StudentService 
   //public projectProposal: any;
//   //initialize the call using Project Proposal app 
 // constructor(/*private _myService: StudentService,*/ private _projectProposal: ProjectProposalService) { }
//    ngOnInit() {
// //       this.getStudents();
//        this.getProjectProfile();
//    }
//   //method called OnInit
//    getProjectProfile() {
//     this._projectProposal.getProjectProfile().subscribe(
//         //read data and assign to public variable projectProposal
//         data => { this.projectProposal = data},
//         err => console.error(err),
//         () => console.log('finished loading')
//     );
// }
// onDelete(projectId: string) {
//   this._projectProposal.deleteProject(projectId);
// }

//   //method called OnInit
//   getStudents() {
//       this._myService.getStudents().subscribe(
//           //read data and assign to public variable students
//           data => { this.students = data},
//           err => console.error(err),
//           () => console.log('finished loading')
//       );
//   }
  
//   onDelete(studentId: string) {
//     this._myService.deleteStudent(studentId);
// }
     
}
  
