import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ProfileEditorComponent } from './profile-editor/profile-editor.component';
import { UnlessDirective } from './unless.directive';
import { HttpClientModule } from '@angular/common/http';
//import { StudentService } from './student.service';
//import { NewStudentFormComponent } from './new-student-form/new-student-form.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { ProjectProposalService } from './projectProposal.service';
import { NavigationMenuComponent } from './navigation-menu/navigation-menu.component';
import { Routes, RouterModule } from '@angular/router';
//import { ListStudentsComponent } from './list-students/list-students.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { ListProjectsComponent } from './list-projects/list-projects.component';


const appRoutes: Routes = [ {
  path: 'addProject',
  component: ProfileEditorComponent
},
{
  path: 'listProject',
  component: ListProjectsComponent
},
{
  path: 'editProject/:_id',
  component: ProfileEditorComponent
}
];


@NgModule({
  declarations: [
    AppComponent,
    ProfileEditorComponent,
    UnlessDirective,
    //NewStudentFormComponent,
    NavigationMenuComponent,
    //ListStudentsComponent,
    NotFoundComponent,
    ListProjectsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [/*StudentService,*/ProjectProposalService],
  bootstrap: [AppComponent]
})
export class AppModule { }
