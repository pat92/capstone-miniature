import { Component, OnInit } from '@angular/core';
import { ProjectProposalService } from '../projectProposal.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-list-projects',
  templateUrl: './list-projects.component.html',
  styleUrls: ['./list-projects.component.css']
})
export class ListProjectsComponent implements OnInit {
  title ='Capstone Project Proposal App';

  public projectProposal: any;
  //   //initialize the call using Project Proposal app 
    constructor(/*private _myService: StudentService,*/ private _projectProposal: ProjectProposalService, private router:Router ) { }
     ngOnInit() {
  //       this.getStudents();
         this.getProjectProposals();
     }
  //   //method called OnInit
  getProjectProposals() {
  this._projectProposal.getProjectProposals().subscribe(
      //read data and assign to public variable projectProposal
      data => { this.projectProposal = data},
      err => console.error(err),
      () => console.log('finished loading')
  );
}
  onDelete(projectId: string) {
    this._projectProposal.deleteProject(projectId);
  }
}
