import { Component, OnInit, Input  } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FormArray } from '@angular/forms';
import { ProjectProposalService } from '../projectProposal.service';
import {Router} from '@angular/router';
import {ActivatedRoute, ParamMap } from '@angular/router';


@Component({
  selector: 'app-profile-editor',
  templateUrl: './profile-editor.component.html',
  styleUrls: ['./profile-editor.component.css']
})
export class ProfileEditorComponent implements OnInit {
@Input() contactName: string = "";
@Input() contactJobTitle: string = "";
@Input() contactEmail: string = "";
@Input() contactPhone: string = "";
@Input() organizationName: string = "";
@Input() street: string = "";
@Input() zip2: string = "";
@Input() city: string = "";
@Input() state: string = "";
@Input() organizationWebsite: string = "";
@Input() projectTitle: string = "";
@Input() description: string = "";
@Input() background: string = "";
@Input() problemStmnt: string = "";
@Input() objectives: string = "";
@Input() techSkill: string = "";
@Input() task1: string = "";
@Input() task2: string = "";
@Input() task3: string = "";
@Input() task4: string = "";
@Input() task1time: string = "";
@Input() task2time: string = "";
@Input() task3time: string = "";
@Input() task4time: string = "";
@Input() educationalGrowth: string = "";
@Input() professionalGrowth: string = "";
@Input() training: string = "";
@Input() data: string = "";
@Input() equipment: string = "";
@Input() traveling: string = "";

public mode = 'Add'; //default mode
private id: any; //project ID
private project: any;

//   //initialize the call using StudentService 

  profileForm = this.fb.group({
    contactName: ['', Validators.required],
    contactJobTitle: ['', Validators.required],
    contactEmail: ['', Validators.required],
    contactPhone: ['', Validators.required],
    organizationName: ['', Validators.required],
    street:['', Validators.required],
    zip2: ['', Validators.required],
    city: ['', Validators.required],
    state:['', Validators.required],
    organizationWebsite: ['', Validators.required],
    projectTitle:['', Validators.required],
    projectDescription: this.fb.group({
      description: ['', Validators.required],
      background: ['', Validators.required],
      problemStmnt: ['', Validators.required],
      objectives: ['', Validators.required]
    }),
    techSkill:[''],
    duties: this.fb.group({
      task1:['',Validators.required],
      task2:['',Validators.required],
      task3:['',Validators.required],
      task4:['',Validators.required],
      task1time:['',Validators.required],
      task2time:['',Validators.required],
      task3time:['',Validators.required],
      task4time:['',Validators.required],
    }),
    benefits: this.fb.group({
      educationalGrowth:[''],
      professionalGrowth:['']
    }),
    companySupport:this.fb.group({
      training:[''], 
      data:[''], 
      equipment:[''], 
      traveling:['']
    }),

    // aliases: this.fb.array([
    //   this.fb.control('')
    // ])
  });

  get aliases() {
    return this.profileForm.get('aliases') as FormArray;
  }
  addAlias() {
    this.aliases.push(this.fb.control(''));
  }

  constructor(private fb: FormBuilder,private _projectService: ProjectProposalService, private router:Router, public route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe((paramMap: ParamMap ) => {
      if (paramMap.has('_id'))
          { 
          this.mode = 'Edit'; /*request had a parameter _id */ 
          this.id = paramMap.get('_id');
           //request student info based on the id
           this._projectService.getProjectProposal(this.id).subscribe(
            data => { 
                //read data and assign to private variable student
                this.project = data;
                //populate the firstName and lastName on the page
                //notice that this is done through the two-way bindings
                this.contactName = this.project.contactName;
                this.contactJobTitle = this.project.contactJobTitle;
                this.contactEmail = this.project.contactEmail;
                this.contactPhone = this.project.contactPhone;
                this.organizationName = this.project.organizationName;
                this.organizationWebsite = this.project.organizationWebsite;                                
            },
            err => console.error(err),
            () => console.log('finished loading')
        );
    } 
      else {this.mode = 'Add';
          this.id = null; }
  });
  }


  onSubmit() {
    // TODO: Use EventEmitter with form value
    console.log("You submitted: " + this.contactName + " " + this.contactJobTitle+ " " + this.contactEmail+ " " + this.contactPhone+" "+this.organizationName+" "+this.organizationWebsite);
    if (this.mode == 'Add')
      this._projectService.addProjectProposal(this.contactName,this.contactJobTitle,this.contactEmail,this.contactPhone, this.organizationName, this.organizationWebsite);
    if (this.mode == 'Edit')
      this._projectService.updateProjectProposal(this.id,this.contactName,this.contactJobTitle,this.contactEmail,this.contactPhone, this.organizationName, this.organizationWebsite);
    this.router.navigate(['/listProject']);
  }

zip: any = {
  "Kennesaw": ["30144", "30152" ],
  "Marietta":[ "30060", "30061", "30062", "30063", "30064", "30065", "30066", "30067", "30068", "30069" ],
  "Woodstock":[ "30188", "30189" ]
};

getCity = (theCurrentZip: any) => {
  return Object.keys(this.zip).filter(z => {
    return this.zip[z].includes(theCurrentZip)
  })[0]
}

applyFilter(event: any){
      this.city= this.getCity(event.target.value)
    }

}
