import { Directive, Input, OnChanges, HostBinding } from '@angular/core';

@Directive({
  selector: '[appAnimalImage]'
})
export class AnimalImageDirective implements OnChanges{

  constructor() { }
  @Input() animalName: string = "";
  @HostBinding('src') imageSource = "";

  ngOnChanges() {
    this.imageSource = '../assets/default.svg.png';
    if(this.animalName){
        if (this.animalName.indexOf('dog') > -1) 
            this.imageSource = '../assets/dog.svg.png';
        if (this.animalName.indexOf('cat') > -1)  
            this.imageSource = '../assets/cat.svg.png';
    }
}
}
