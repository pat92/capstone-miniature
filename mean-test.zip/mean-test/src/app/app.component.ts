import { Component } from '@angular/core';
//import { off } from 'process';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'IT6203';
  formName="Registration Form";
  onoff= false;
  condition=true;
  users = ['jdow', 'asmith', 'jdoe'];
  animalNameInput="";

  json = `[ { "firstName" : "John" , "lastName" : "Dow" }, 
  { "firstName" : "Ann" , "lastName" : "Smith" }, 
  { "firstName" : "Joan" , "lastName" : "Doe" }]`;
  students = JSON.parse(this.json);
                    
}
